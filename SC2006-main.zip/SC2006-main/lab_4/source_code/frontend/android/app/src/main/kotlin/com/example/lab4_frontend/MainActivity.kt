package com.example.lab4_frontend

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
